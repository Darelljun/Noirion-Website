Diese Figma Make-Datei enthält Komponenten von [shadcn/ui](https://ui.shadcn.com/), verwendet unter [MIT-Lizenz](https://github.com/shadcn-ui/ui/blob/main/LICENSE.md).

Diese Figma Make-Datei enthält Fotos von [Unsplash](https://unsplash.com), die unter [Lizenz](https://unsplash.com/license) verwendet werden.